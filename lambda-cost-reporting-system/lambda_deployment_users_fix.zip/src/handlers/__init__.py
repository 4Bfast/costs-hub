# Simple handlers without external dependencies
