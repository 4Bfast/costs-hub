"""
Accounts Handler - Account management
"""
import json
import boto3
import uuid
from datetime import datetime
from botocore.exceptions import ClientError

# Initialize DynamoDB client
dynamodb = boto3.resource('dynamodb')
accounts_table = dynamodb.Table('costhub-accounts')

def validate_authorization_inline(event, cors_headers):
    """Inline authorization validation"""
    headers = event.get('headers', {})
    auth_header = headers.get('Authorization') or headers.get('authorization', '')
    
    if not auth_header.startswith('Bearer '):
        return False, {
            'statusCode': 401,
            'headers': cors_headers,
            'body': json.dumps({'message': 'Unauthorized'})
        }, None
    
    access_token = auth_header.replace('Bearer ', '')
    
    try:
        cognito = boto3.client('cognito-idp', region_name='us-east-1')
        response = cognito.get_user(AccessToken=access_token)
        return True, None, {'username': response['Username']}
    except:
        return False, {
            'statusCode': 401,
            'headers': cors_headers,
            'body': json.dumps({'message': 'Unauthorized'})
        }, None

def handle_accounts_request(event, cors_headers):
    """Handle accounts endpoints"""
    # Validate authorization first
    is_valid, error_response, user_info = validate_authorization_inline(event, cors_headers)
    if not is_valid:
        return error_response
    
    path = event['path']
    method = event['httpMethod']
    
    try:
        if method == 'GET' and path.endswith('/accounts'):
            return handle_get_accounts(cors_headers)
        elif method == 'POST' and path.endswith('/accounts'):
            return handle_create_account(event, cors_headers)
        elif method == 'PUT' and '/accounts/' in path:
            return handle_update_account(event, cors_headers)
        elif method == 'DELETE' and '/accounts/' in path:
            return handle_delete_account(event, cors_headers)
        else:
            return {
                'statusCode': 404,
                'headers': cors_headers,
                'body': json.dumps({'error': 'Accounts endpoint not found'})
            }
    except Exception as e:
        return {
            'statusCode': 500,
            'headers': cors_headers,
            'body': json.dumps({'error': f'Accounts error: {str(e)}'})
        }

def handle_get_accounts(cors_headers):
    """Get all accounts from DynamoDB"""
    try:
        response = accounts_table.scan()
        accounts = response.get('Items', [])
        
        return {
            'statusCode': 200,
            'headers': cors_headers,
            'body': json.dumps({
                'message': 'Accounts retrieved successfully',
                'accounts': accounts,
                'count': len(accounts)
            })
        }
    except Exception as e:
        return {
            'statusCode': 500,
            'headers': cors_headers,
            'body': json.dumps({'error': f'Failed to retrieve accounts: {str(e)}'})
        }

def handle_create_account(event, cors_headers):
    """Create a new account in DynamoDB"""
    try:
        # Parse request body
        body_data = json.loads(event.get('body', '{}'))
        
        # Validate required fields
        required_fields = ['name', 'provider_type']
        for field in required_fields:
            if not body_data.get(field):
                return {
                    'statusCode': 400,
                    'headers': cors_headers,
                    'body': json.dumps({'error': f'Missing required field: {field}'})
                }
        
        # Create account record
        account_id = str(uuid.uuid4())
        timestamp = datetime.utcnow().isoformat() + 'Z'
        
        account = {
            'account_id': account_id,
            'name': body_data['name'],
            'provider_type': body_data['provider_type'],
            'credentials': body_data.get('credentials', {}),
            'status': 'active',
            'created_at': timestamp,
            'updated_at': timestamp
        }
        
        # Save to DynamoDB
        accounts_table.put_item(Item=account)
        
        return {
            'statusCode': 201,
            'headers': cors_headers,
            'body': json.dumps({
                'message': 'Account created successfully',
                'account': account
            })
        }
        
    except json.JSONDecodeError:
        return {
            'statusCode': 400,
            'headers': cors_headers,
            'body': json.dumps({'error': 'Invalid JSON in request body'})
        }
    except Exception as e:
        return {
            'statusCode': 500,
            'headers': cors_headers,
            'body': json.dumps({'error': f'Failed to create account: {str(e)}'})
        }

def handle_update_account(event, cors_headers):
    """Handle PUT /accounts/{id} - Update account"""
    try:
        # Extract account ID from path
        path_parts = event['path'].split('/')
        account_id = path_parts[-1] if len(path_parts) > 0 else None
        
        if not account_id:
            return {
                'statusCode': 400,
                'headers': cors_headers,
                'body': json.dumps({'error': 'Account ID required'})
            }
        
        # Parse request body
        body_data = json.loads(event.get('body', '{}'))
        
        # Get existing account
        response = accounts_table.get_item(Key={'account_id': account_id})
        if 'Item' not in response:
            return {
                'statusCode': 404,
                'headers': cors_headers,
                'body': json.dumps({'error': 'Account not found'})
            }
        
        # Update account
        account = response['Item']
        account['updated_at'] = datetime.utcnow().isoformat() + 'Z'
        
        # Update allowed fields
        updatable_fields = ['name', 'provider_type', 'credentials', 'status']
        for field in updatable_fields:
            if field in body_data:
                account[field] = body_data[field]
        
        # Save updated account
        accounts_table.put_item(Item=account)
        
        return {
            'statusCode': 200,
            'headers': cors_headers,
            'body': json.dumps({
                'message': 'Account updated successfully',
                'account': account
            })
        }
        
    except json.JSONDecodeError:
        return {
            'statusCode': 400,
            'headers': cors_headers,
            'body': json.dumps({'error': 'Invalid JSON in request body'})
        }
    except Exception as e:
        return {
            'statusCode': 500,
            'headers': cors_headers,
            'body': json.dumps({'error': str(e)})
        }

def handle_delete_account(event, cors_headers):
    """Handle DELETE /accounts/{id} - Delete account"""
    try:
        # Extract account ID from path
        path_parts = event['path'].split('/')
        account_id = path_parts[-1] if len(path_parts) > 0 else None
        
        if not account_id:
            return {
                'statusCode': 400,
                'headers': cors_headers,
                'body': json.dumps({'error': 'Account ID required'})
            }
        
        # Check if account exists
        response = accounts_table.get_item(Key={'account_id': account_id})
        if 'Item' not in response:
            return {
                'statusCode': 404,
                'headers': cors_headers,
                'body': json.dumps({'error': 'Account not found'})
            }
        
        # Delete account
        accounts_table.delete_item(Key={'account_id': account_id})
        
        return {
            'statusCode': 200,
            'headers': cors_headers,
            'body': json.dumps({'message': 'Account deleted successfully'})
        }
        
    except Exception as e:
        return {
            'statusCode': 500,
            'headers': cors_headers,
            'body': json.dumps({'error': str(e)})
        }
