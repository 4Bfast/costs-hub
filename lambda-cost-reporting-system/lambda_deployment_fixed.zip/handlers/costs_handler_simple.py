"""
Cost Data Handler - AWS Cost Explorer Integration
"""
import json

# Import auth utils with correct path for Lambda
try:
    from utils.auth_utils import validate_authorization
except ImportError:
    import sys
    import os
    sys.path.append("/var/task")
    from utils.auth_utils import validate_authorization

sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from utils.auth_utils import validate_authorization

def get_cost_data(start_date, end_date, granularity='DAILY', group_by=None, metrics=['UnblendedCost']):
    """Get cost data from AWS Cost Explorer"""
    try:
        ce_client = boto3.client('ce', region_name='us-east-1')
        
        params = {
            'TimePeriod': {
                'Start': start_date,
                'End': end_date
            },
            'Granularity': granularity,
            'Metrics': metrics
        }
        
        if group_by:
            params['GroupBy'] = [{'Type': 'DIMENSION', 'Key': group_by}]
        
        response = ce_client.get_cost_and_usage(**params)
        return response
        
    except ClientError as e:
        raise Exception(f"Cost Explorer error: {str(e)}")

def handle_costs_request(event, cors_headers):
    """Handle costs endpoints"""
    # Validate authorization first
    is_valid, error_response, user_info = validate_authorization(event, cors_headers)
    if not is_valid:
        return error_response
    
    path = event['path']
    method = event['httpMethod']
    
    # Default date range (last 30 days)
    end_date = datetime.now().strftime('%Y-%m-%d')
    start_date = (datetime.now() - timedelta(days=30)).strftime('%Y-%m-%d')
    
    try:
        if method == 'GET':
            if path.endswith('/costs/records'):
                # GET /costs/records - Paginated cost records
                query_params = event.get('queryStringParameters') or {}
                
                # Pagination parameters
                page = int(query_params.get('page', 1))
                limit = int(query_params.get('limit', 20))
                sort = query_params.get('sort', 'date')
                order = query_params.get('order', 'desc')
                
                # Filter parameters
                search = query_params.get('search', '')
                providers = query_params.get('providers', '').split(',') if query_params.get('providers') else []
                services = query_params.get('services', '').split(',') if query_params.get('services') else []
                accounts = query_params.get('accounts', '').split(',') if query_params.get('accounts') else []
                
                # Date range
                filter_start = query_params.get('start_date', start_date)
                filter_end = query_params.get('end_date', end_date)
                
                # Get cost data with service grouping for records
                cost_data = get_cost_data(filter_start, filter_end, group_by='SERVICE')
                
                # Build records list
                records = []
                for result in cost_data['ResultsByTime']:
                    date = result['TimePeriod']['Start']
                    
                    for group in result['Groups']:
                        service_name = group['Keys'][0]
                        cost = float(group['Metrics']['UnblendedCost']['Amount'])
                        
                        # Apply filters
                        if search and search.lower() not in service_name.lower():
                            continue
                        if services and service_name not in services:
                            continue
                        
                        record = {
                            'id': f"{date}_{service_name}",
                            'date': date,
                            'service': service_name,
                            'cost': cost,
                            'provider': 'AWS',
                            'account': 'default',
                            'region': 'us-east-1',
                            'usage_type': 'Standard',
                            'currency': 'USD'
                        }
                        records.append(record)
                
                # Sort records
                reverse = order == 'desc'
                if sort == 'date':
                    records.sort(key=lambda x: x['date'], reverse=reverse)
                elif sort == 'cost':
                    records.sort(key=lambda x: x['cost'], reverse=reverse)
                elif sort == 'service':
                    records.sort(key=lambda x: x['service'], reverse=reverse)
                
                # Pagination
                total = len(records)
                start_idx = (page - 1) * limit
                end_idx = start_idx + limit
                paginated_records = records[start_idx:end_idx]
                
                return {
                    'statusCode': 200,
                    'headers': cors_headers,
                    'body': json.dumps({
                        'data': paginated_records,
                        'pagination': {
                            'page': page,
                            'limit': limit,
                            'total': total,
                            'pages': (total + limit - 1) // limit,
                            'has_next': end_idx < total,
                            'has_prev': page > 1
                        }
                    })
                }
                
            elif path.endswith('/costs'):
                # GET /costs - Overall cost data
                cost_data = get_cost_data(start_date, end_date)
                
                total_cost = 0
                for result in cost_data['ResultsByTime']:
                    total_cost += float(result['Total']['UnblendedCost']['Amount'])
                
                return {
                    'statusCode': 200,
                    'headers': cors_headers,
                    'body': json.dumps({
                        'message': 'Cost data retrieved successfully',
                        'data': {
                            'period': {'start': start_date, 'end': end_date},
                            'totalCost': round(total_cost, 2),
                            'currency': cost_data['ResultsByTime'][0]['Total']['UnblendedCost']['Unit'] if cost_data['ResultsByTime'] else 'USD',
                            'details': cost_data['ResultsByTime']
                        }
                    })
                }
                
            elif path.endswith('/costs/summary'):
                # GET /costs/summary - Cost summary
                cost_data = get_cost_data(start_date, end_date, group_by='SERVICE')
                
                services = []
                total_cost = 0
                
                for result in cost_data['ResultsByTime']:
                    for group in result['Groups']:
                        service_name = group['Keys'][0]
                        service_cost = float(group['Metrics']['UnblendedCost']['Amount'])
                        total_cost += service_cost
                        
                        # Find or create service entry
                        service_entry = next((s for s in services if s['service'] == service_name), None)
                        if service_entry:
                            service_entry['cost'] += service_cost
                        else:
                            services.append({'service': service_name, 'cost': service_cost})
                
                # Sort by cost descending
                services.sort(key=lambda x: x['cost'], reverse=True)
                
                return {
                    'statusCode': 200,
                    'headers': cors_headers,
                    'body': json.dumps({
                        'message': 'Cost summary retrieved successfully',
                        'data': {
                            'totalCost': round(total_cost, 2),
                            'topServices': services[:10],
                            'period': {'start': start_date, 'end': end_date}
                        }
                    })
                }
                
            elif path.endswith('/costs/trends'):
                # GET /costs/trends - Cost trends over time
                cost_data = get_cost_data(start_date, end_date, granularity='DAILY')
                
                trends = []
                for result in cost_data['ResultsByTime']:
                    trends.append({
                        'date': result['TimePeriod']['Start'],
                        'cost': float(result['Total']['UnblendedCost']['Amount'])
                    })
                
                return {
                    'statusCode': 200,
                    'headers': cors_headers,
                    'body': json.dumps({
                        'message': 'Cost trends retrieved successfully',
                        'data': {
                            'trends': trends,
                            'period': {'start': start_date, 'end': end_date}
                        }
                    })
                }
                
            elif path.endswith('/costs/breakdown'):
                # GET /costs/breakdown - Detailed cost breakdown
                cost_data = get_cost_data(start_date, end_date, group_by='SERVICE')
                
                breakdown = []
                for result in cost_data['ResultsByTime']:
                    date = result['TimePeriod']['Start']
                    for group in result['Groups']:
                        breakdown.append({
                            'date': date,
                            'service': group['Keys'][0],
                            'cost': float(group['Metrics']['UnblendedCost']['Amount'])
                        })
                
                return {
                    'statusCode': 200,
                    'headers': cors_headers,
                    'body': json.dumps({
                        'message': 'Cost breakdown retrieved successfully',
                        'data': {
                            'breakdown': breakdown,
                            'period': {'start': start_date, 'end': end_date}
                        }
                    })
                }
                
            elif path.endswith('/costs/by-service'):
                # GET /costs/by-service - Costs grouped by service
                cost_data = get_cost_data(start_date, end_date, group_by='SERVICE')
                
                services = {}
                for result in cost_data['ResultsByTime']:
                    for group in result['Groups']:
                        service_name = group['Keys'][0]
                        service_cost = float(group['Metrics']['UnblendedCost']['Amount'])
                        
                        if service_name not in services:
                            services[service_name] = 0
                        services[service_name] += service_cost
                
                # Convert to list and sort
                service_list = [{'service': k, 'cost': round(v, 2)} for k, v in services.items()]
                service_list.sort(key=lambda x: x['cost'], reverse=True)
                
                return {
                    'statusCode': 200,
                    'headers': cors_headers,
                    'body': json.dumps({
                        'message': 'Costs by service retrieved successfully',
                        'data': {
                            'services': service_list,
                            'period': {'start': start_date, 'end': end_date}
                        }
                    })
                }
                
            elif path.endswith('/costs/by-region'):
                # GET /costs/by-region - Costs grouped by region
                cost_data = get_cost_data(start_date, end_date, group_by='REGION')
                
                regions = {}
                for result in cost_data['ResultsByTime']:
                    for group in result['Groups']:
                        region_name = group['Keys'][0] or 'Global'
                        region_cost = float(group['Metrics']['UnblendedCost']['Amount'])
                        
                        if region_name not in regions:
                            regions[region_name] = 0
                        regions[region_name] += region_cost
                
                # Convert to list and sort
                region_list = [{'region': k, 'cost': round(v, 2)} for k, v in regions.items()]
                region_list.sort(key=lambda x: x['cost'], reverse=True)
                
                return {
                    'statusCode': 200,
                    'headers': cors_headers,
                    'body': json.dumps({
                        'message': 'Costs by region retrieved successfully',
                        'data': {
                            'regions': region_list,
                            'period': {'start': start_date, 'end': end_date}
                        }
                    })
                }
        
        elif method == 'POST':
            if path.endswith('/costs/export'):
                # POST /costs/export - Export cost data
                try:
                    body_data = json.loads(event.get('body', '{}'))
                except json.JSONDecodeError:
                    return {
                        'statusCode': 400,
                        'headers': cors_headers,
                        'body': json.dumps({'error': 'Invalid JSON in request body'})
                    }
                
                # Export parameters
                export_format = body_data.get('format', 'csv')  # csv, excel, pdf
                filters = body_data.get('filters', {})
                columns = body_data.get('columns', ['date', 'service', 'cost'])
                date_range = body_data.get('date_range', {})
                
                # Use date range from request or default
                export_start = date_range.get('start', start_date)
                export_end = date_range.get('end', end_date)
                
                # Get cost data for export
                cost_data = get_cost_data(export_start, export_end, group_by='SERVICE')
                
                # Build export data
                export_records = []
                for result in cost_data['ResultsByTime']:
                    date = result['TimePeriod']['Start']
                    
                    for group in result['Groups']:
                        service_name = group['Keys'][0]
                        cost = float(group['Metrics']['UnblendedCost']['Amount'])
                        
                        # Apply filters if provided
                        if filters.get('services') and service_name not in filters['services']:
                            continue
                        if filters.get('min_cost') and cost < filters['min_cost']:
                            continue
                        if filters.get('max_cost') and cost > filters['max_cost']:
                            continue
                        
                        record = {
                            'date': date,
                            'service': service_name,
                            'cost': cost,
                            'provider': 'AWS',
                            'account': 'default',
                            'region': 'us-east-1',
                            'currency': 'USD'
                        }
                        
                        # Filter columns
                        filtered_record = {col: record.get(col, '') for col in columns}
                        export_records.append(filtered_record)
                
                # Generate job ID (simulate async processing)
                import uuid
                job_id = str(uuid.uuid4())
                
                # For now, return immediate response with data
                # In production, this would be async with S3 upload
                return {
                    'statusCode': 200,
                    'headers': cors_headers,
                    'body': json.dumps({
                        'job_id': job_id,
                        'status': 'completed',
                        'format': export_format,
                        'records_count': len(export_records),
                        'download_url': f'https://api-costhub.4bfast.com.br/costs/export/{job_id}/download',
                        'data': export_records[:100] if export_format == 'json' else None,  # Return first 100 for JSON
                        'message': f'Export completed with {len(export_records)} records'
                    })
                }
        
        return {
            'statusCode': 404,
            'headers': cors_headers,
            'body': json.dumps({'error': 'Cost endpoint not found'})
        }
        
    except Exception as e:
        return {
            'statusCode': 500,
            'headers': cors_headers,
            'body': json.dumps({'error': f'Cost data error: {str(e)}'})
        }
